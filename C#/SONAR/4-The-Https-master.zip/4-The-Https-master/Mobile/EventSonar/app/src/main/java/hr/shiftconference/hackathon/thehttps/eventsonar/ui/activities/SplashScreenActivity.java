package hr.shiftconference.hackathon.thehttps.eventsonar.ui.activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import hr.shiftconference.hackathon.thehttps.eventsonar.R;

public class SplashScreenActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);
    }
}
