﻿NewEventController.$inject = ["$scope", "$http"];
function NewEventController($scope, $http) {

}

sonar.controller('newEventController', NewEventController);