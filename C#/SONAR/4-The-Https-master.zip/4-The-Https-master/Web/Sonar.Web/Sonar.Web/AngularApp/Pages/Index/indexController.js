﻿indexController.$inject = ["$scope", "$http"];
function indexController($scope, $http) {

}

sonar.controller('indexController', indexController);