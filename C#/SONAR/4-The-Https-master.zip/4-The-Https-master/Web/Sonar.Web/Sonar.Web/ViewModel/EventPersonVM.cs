﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Sonar.Web.ViewModel
{
    public class EventPersonVM
    {
        public int Id;
        public int EventId;
        public int PersonId;
    }
}