﻿namespace Sonar.ViewModels
{
    public class TownVM
    {
        public string Name;
        public int Id;
    }
}