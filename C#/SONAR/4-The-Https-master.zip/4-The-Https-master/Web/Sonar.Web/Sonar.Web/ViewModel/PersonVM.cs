﻿using System;
namespace Sonar.ViewModels
{
    public class PersonVM
    {
        public string ImageUrl;
        public DateTime? BirthDate;
        public string FirstName;
        public string LastName;
        public int Rating;
        public string Username;
        public string Password;
        public string Email;
        public int Id;
        public string PersonType;
        public string PersonTypeId;
    }
}